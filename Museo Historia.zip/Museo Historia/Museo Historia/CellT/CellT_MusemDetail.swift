//
//  CellT_MusemDetail.swift
//  Museo Historia
//
//  Created by syed fazal abbas on 03/09/23.
//

import UIKit

class CellT_MusemDetail: UITableViewCell {
    
    @IBOutlet var img_museum: UIImageView!
    @IBOutlet var lbl_nameMuseum: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
