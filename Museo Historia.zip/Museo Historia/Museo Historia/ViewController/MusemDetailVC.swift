//
//  MusemDetailVC.swift
//  Museo Historia
//
//  Created by syed fazal abbas on 03/09/23.
//

import UIKit

class MusemDetailVC: UIViewController {
    var artScience : String?
    var historical : String?
    var science : String?
    var military : String?
    var archaeological : String?
    @IBOutlet var txt_Detail: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        if let artSciencedetail = artScience {
                    // Set the text view to display the museum detail
                    txt_Detail.text = artSciencedetail
                }
        if let histrocialdetail = historical {
                    // Set the text view to display the museum detail
                    txt_Detail.text = histrocialdetail
                }
        if let scienceDetail = science {
                    // Set the text view to display the museum detail
                    txt_Detail.text = scienceDetail
                }
        if let militaryDetail = military {
                    // Set the text view to display the museum detail
                    txt_Detail.text = militaryDetail
                }
        if let archaeologicalDetail = archaeological {
                    // Set the text view to display the museum detail
                    txt_Detail.text = archaeologicalDetail
                }
//
    }
}
