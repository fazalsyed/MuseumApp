//
//  LetsStartVC.swift
//  Museo Historia
//
//  Created by syed fazal abbas on 03/09/23.
//

import UIKit

class LetsStartVC: UIViewController {

        @IBOutlet weak var btn: UIButton!
    @IBOutlet var img: UIImageView!
    @IBOutlet weak var animatedLabel: UILabel!
        let textToAnimate = " Museo Historia" // Replace this with the desired text
            
            var currentIndex = 0
            var animationTimer: Timer?
        
        override func viewDidLoad() {
            super.viewDidLoad()
            img.layer.cornerRadius = 20
            btn.layer.cornerRadius = 20
            btn.layer.shadowOpacity = 10
            
            animatedLabel.text = ""
            startAnimation()
            animateView(btn: btn, position: CGPoint(x: view.frame.width / 2, y: view.frame.height / 2), delay: 0.5)
            
        }
        
    
    @IBAction func tappedNextVC(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "CategoryVC") as? CategoryVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
        func animateView(btn: UIButton, position: CGPoint, delay: TimeInterval) {
            btn.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
            btn.alpha = 0.0
            
            UIButton.animate(withDuration: 1.0, delay: delay, options: [.curveEaseInOut], animations: {
                btn.transform = .identity
                btn.alpha = 1.0
                btn.center = position
            }, completion: nil)
        }
        
        func startAnimation() {
                currentIndex = 0
                animatedLabel.text = ""
                
                // Create a timer to update the label
            animationTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(updateLabel), userInfo: nil, repeats: true)
            }
            
            @objc func updateLabel() {
                // Check if we've reached the end of the text
                if currentIndex < textToAnimate.count {
                    let index = textToAnimate.index(textToAnimate.startIndex, offsetBy: currentIndex)
                    let charToAdd = String(textToAnimate[index])
                    animatedLabel.text?.append(charToAdd)
                    currentIndex += 1
                } else {
                    // Stop the timer once animation is complete
                    animationTimer?.invalidate()
                    animationTimer = nil
                }
            }

    }

