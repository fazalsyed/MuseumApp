//
//  CategoryVC.swift
//  Museo Historia
//
//  Created by syed fazal abbas on 03/09/23.
//

import UIKit


class CategoryVC: UIViewController {
    
    var arrCategoryimg : [String] = ["ic_Fine_arts","ic_Historical","ic_Science_Museum","ic_General","ic_ Archaeological"]
    var arrCategoryName : [String] = ["Fine arts","Historical","Science","Military","Archaeological"]
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "CellT_Category", bundle: nil), forCellReuseIdentifier: "CellT_Category")
    }
}
extension CategoryVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrCategoryName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_Category") as! CellT_Category
        cell.lbl_category.text = arrCategoryName[indexPath.row]
        cell.img_Cateogry.image = UIImage(named: arrCategoryimg[indexPath.row])
        cell.img_Cateogry.layer.cornerRadius = 10
        cell.vwCategory.layer.cornerRadius = 5
        cell.vwCategory.layer.borderWidth = 1
        cell.vwCategory.layer.borderColor = UIColor.white.cgColor
        cell.selectedBackgroundView?.isHidden = true
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController
        vc?.selectedIndex = indexPath.row
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
