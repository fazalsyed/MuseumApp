//
//  ViewController.swift
//  Museo Historia
//
//  Created by syed fazal abbas on 03/09/23.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet var lbl_MusemName: UILabel!
    @IBOutlet var tableView: UITableView!
    var selectedIndex: Int?
    //Mark : Fine Art Museum Array
    var ArrFineArt : [String] = ["Academy of Fine Arts, Kolkata","The Government Museum,Chandigarh","Government Museum, Chennai","Indian Museum Kolkata","Jehangir Art Gallery, Mumbai"]
    var ArrFineImg : [String] = ["ic_acadmia_kolkata","ic_govermet_Chandigarh","ic_goverment_chennai","ic_Indian_kolkata","ic_jahagirart_Mumbai"]
    
    var ArrFineDetail : [String] = ["Established in 1933, the Academy of Fine Arts in Kolkata is one of the most significant art galleries in India. Various famous paintings by eminent Indian and foreign artists are displayed here. Some of the famous paintings include 'Girl with a pitcher' and 'A Winter's Evening' by Rabindra Nath Tagore. Works of artists like Jamini Roy, Nandalal Bose, M.F.Hussain, etc, are also showcased at the academy.","Sculptures are also on display apart from paintings at this prominent museum located in Chandigarh. Started for the public in 1968, the museum features different sections for sculpture, architecture and art paintings. The best sections of the museum consist of sections for Indian miniature paintings, contemporary art, portraits, etc. Paintings by some of the most illustrious artists like Raja Ravi Varma, Amrita Sher-Gil, Jamini Roy, Rabindranath Tagore, Nandalal Bose, Abanindranath Tagore, etc are part of the museum.","Also known as the Madras Museum, the Government Museum in Chennai is the second oldest museum and art gallery in India. Established in the year 1851, it witnesses a heavy footfall of visitors each year. The National Art Gallery, which forms a part of the museum, has paintings of legendary artists like Raja Ravi Varma on display. Traditional paintings of Tanjore, Rajput and Mughal era along with paintings of the contemporary period can be found here.","Established in 1814, the Indian Museum is known for preserving the heritage artworks of India. The museum is divided into six sections and the art gallery of the museum is divided into 4 sections which feature Mughal Painting Gallery, Bengal Painting Gallery, Decorative Art and Textile Gallery along with South East Asian Gallery.","Established in 1952, Jehangir Art Gallery in Mumbai is owned by a private organization and has paintings of almost all famous Indian artists from Jamini Roy to Arpita Singh. Artists from India and abroad line up to get their work exhibited at this gallery. It is a must visit for art lovers as you will get to see some of the finest art creations of the world at this gallery."]
    
    //Mark : Historical Museum Array
    var ArrHistoricalimg : [String] = ["ic_National","ic_Delhi","ic_Shankar","ic_Sulabh","ic_kite"]
    var ArrHistoricalname : [String] = ["INDIAN MUSEUM, WEST BENGAL","NATIONAL MUSUEM, NEW DELHI","SHANKAR’S INTERNATIONAL, NEW DELHI","SULABH INTERNATIONAL, NEW DELHI","KITES MUSUEM, GUJARAT"]
    var ArrHistoryDetail : [String] = ["Situated in Kolkata and also referred to as the Imperial Museum at Calcutta this is the oldest museum of India, built in 1814 by the Asiatic Society of Bengal. It also happens to be the largest museum with collections of fossils, skeletons, mummies and even Mughal paintings from as early as 1600 C.E. The museum is divided into six sections and has thirty-five galleries displaying a number of artifacts of natural history as well as Egyptian history.","Situated in the capital city, this museum has collections from pre-historic times to contemporary times. Being one of the largest museums in the country, it sure lives up to the hype as it displays sources ranging from sculptures, decorative art, manuscripts, paintings, armors, numismatics, fossils to textiles, musical instruments, skeletal remains and what not.","Set up by Shankar Pillai, the political cartoonist the museum displays a large collection of traditional dolls from around the world ranging from cloth dolls, wooden dolls to mud dolls. The museum is divided into two halves; the first section displays the dolls from Europe, US, Australia and Commonwealth of Independent states and the second section displays dolls from Asia, Africa and the Middle-East. Certain sections show dolls engaging in day to day activities and oh, there are scary dolls as well! ","This museum is nothing short of uncanny. As the name suggests, the museum shows a collection of toilets from different time periods and places around the world, it also enlightens us on the technology development in toilet building since date. Though the museum might seem like a weird establishment, the reason for its foundation was to spread awareness about the lack of toilets present all over the country and to also highlight the unhygienic conditions in which most public toilets are in remote rural areas.","Situated in Ahmedabad, the hub of kite making, this museum showcases almost 150 varieties of it. Kites have always been significant in context of India as their importance goes back to the days of independence when the kite flying tradition was pioneered. And though this custom may slowly be diminishing, the museum stands as an undying reminder for their importance."]
    //Mark : Science Museum Array
    var ArrScienceName : [String] = ["Nehru Science Centre, Mumbai","National Science Centre, Delhi","Birla Science Museum, Hyderabad","Visvesvaraya Industrial, Bengaluru","Birla Industrial, Kolkata"]
    var ArrScineceImg : [String] = ["ic_Nehru","ic_Nationa","ic_birla","ic _Visvesvaraya","ic_birlaIndustris"]
    var ArrScienceDetail : [String] = ["This is one of the most popular science museums in India where you can witness over 500 science exhibits, both hands-on and interactive. The exhibits are based on various themes such as sound, energy, mechanics, kinematics, and transportation, and are featured in various galleries as well as the science park. 3D and Science on Sphere shows are conducted daily here. This is an incredible place for school students as workshops and science fairs are held on a regular basis. From February 22nd to 28th, National Science Day is celebrated by the center here.","This science center in Delhi was inaugurated in 1992 and is one of the biggest science centres in Asia. You would often see students visiting this place. The main attraction of this place is the Energy Ball. The other galleries have themes such as human biology, water, fun science, prehistoric life, nuclear power, and emerging tech. One of the galleries is totally dedicated to Sardar Vallabhbhai Patel. The center is located in the Pragati Maidan complex and regular science shows are conducted here. Your kids will get a lot of chances to learn many things here.","Birla Planetarium and Science Museum in Hyderabad has gained a lot of attention for housing Dinosaurium, which is one of the best in the entire world. This centre was started in 2000 and you can witness a lot of fossils of dinosaurs which are as old as 160 million years. Apart from this, you can also take a tour of the science museum as well as the space museum. The aim of showcasing the exhibits in the museum is to teach the basic laws of physics, mechanics, perception, optical illusions. The attractions of the space museum here are the satellites, spacecraft, and rockets that are all given by the ISRO.","Visvesvaraya Industrial and Technological Museum dates back to 962 and is the oldest science museum in the country. The science museum was established to pay a tribute to Bharat Ratna Sir M. Visvesvaraya. There are two special exhibits and seven exhibition halls in this museum. The major attraction of this science museum is the aeroplane that was made by the Wright Brothers. You can watch 3D movies on the Fun Science gallery screens. As you visit the other galleries, you will get to learn about dinosaurs, electronics, and biotechnology.  A must-visit is the Science on a Sphere and ElectroTechnic gallery. As you visit the science park, you can see the airplanes and the steam engines.","Under the National Council of Science Museums of the Ministry of Culture, this was the first science museum in India. This is one of the best science museums in India which is often frequented by students and science enthusiasts. One can learn a lot through the exhibitions, interactive models, and educational programmes as well as activities that are conducted throughout the year. There are several facilities at the museum which enable the students to understand the concepts of astronomy, chemistry, physics, biology, mathematics, electricity, and electronics. You along with your kids also must attend the Taramandal show as you can learn about the stars as well as constellations. There is also a scope of attending the Sky Observation Programme in which they use a 10-inch Telescope"]
    
    //Mark : military Musem Array
    var ArrmilitaryName : [String] = ["Army Heritage, Himachal Pradesh","Jaisalmer War, Jaisalmer, Rajasthan","Artillery, Maharashtra","Naval Aviation Museum, Goa","Airforce Museum, Palam, Delhi"]
    var ArrmilitaryImg : [String] = ["ic_Shimla","ic_Rajastahan","ic_MH","ic_Goa","ic_Delhi"]
    var ArrmilitaryDetail : [String] = ["The Annadale glade is the largest stretch of flat land in Shimla. Away from the hustle and bustle of the primary tourist spots, Annadale retains its forest-frilled charm. The Durand Football Tournament was first held here in 1888, and now it is used as a helipad by the Army Heritage Museum. The museum is at an altitude of 6,117 feet above sea level and is home to a collection of modern and traditional weapons, uniforms, flags, armoury, etc. The vast and rich history of the Indian army is on glorious display here, with collectibles dating back to 2,500 BC, as well as mementoes from the Indo-Pak war of 1971 and the Kargil war. In the vicinity is a small Cactus Museum, which should not be missed out on.","In the heart of Rajasthan, located 10 km from Jaisalmer, on the Jaisalmer-Jodhpur highway, is the Jaisalmer War Museum. Dedicated to the contribution, sacrifice, and bravery of the Indian army soldiers, you will see the many war trophies and vintage equipment on display. This includes battle tanks and other military vehicles. The pride of place is occupied by the mural, which depicts the sacrifice which led to victory in the Batter of Laungewala, and the 106 mm Recoilless Gun (a main anti-tank weapon) employed to destroy several enemy tanks. The museum is divided into sections, the Laungewala Hall and the Indian Army Hall, which displays the evolution of the Indian army since the 19th century. It is dedicated to the wars of 1948, 1962, 1965, and the 1999 Kargil war. Spend some time reflecting on the names and sacrifices of the Param Vir Chakra and Mahavir Chakra awardees, memorialised on the Honour Wall. Don’t miss the Light and Sound Show, presented using state-of-the-art audio-visual technology. You can also take a seat for the movie screening of the Battle of Laungewala. The museum is open all week except on national holidays.","Located in the Gandhi Nagar Airport Area, the Artillery Museum was opened to the public in January 2005 by The Regiment of Artillery Association (RAA). It is Asia's biggest such museum and home to vintage and modern weapons, including the Bofors gun, army battle tanks, radar systems, and aircraft. Its main attractions are the AOP aircraft and MIG-23UM, along with historic pieces of artillery such as a wooden catapult from 400 B.C., pot-de-fet artillery (primitive iron cannons first used in Europe. They shot large heavy arrows, instead of cannon balls), and a Mughal brass cannon, from the First Battle of Panipat, fought between Babur and Ibrahim Lodi. Also, on display is the artillery used by the Maratha army, Tipu Sultan’s 102-barrel gun, Rattanban, and artillery used by the British East India Company. There is also the Sexton, a self-propelled gun from World War II. The modern weapons showcased at the museum include those from wars in recent memory, The T-59 tank from the Indo-Pak war of 1971, and the Krishna MK II aircraft. The museum’s premises were formerly used by the British-Indian forces during World War II. Spread across two floors, the museum also showcases military agreements and paintings and photographs of historical events. The museum is closed on Thursdays and public holidays.","The only naval aviation museum in Asia, it was inaugurated in 1998, with a collection of only eight aircraft. At the Naval Aviation Museum, on display in the open-air gallery, are most of the aircraft that the Indian navy has used. The interiors have been designed like the naval aircraft carrier, INS Viraat, and showcase naval equipment, details about prominent battles, a simulation room, and most importantly, the granite plaque, which pays tribute to those who sacrificed their lives for the country. Do not miss the wall dedicated to Goa’s liberation. Recently refurbished with upgraded displays and facilities, the museum now has ramps to assist the differently-abled. There is even a selfie corner and Kshitij, the viewing gallery. The museum remains closed on Mondays and national holidays.","Away from Delhi city centre, the Air Force Museum at Palam Air Force Station exhibits the history of the Indian air force. All displays are detailed in nature and tell the story from the beginning of the Indian air force, when it flew for the Royal Flying Corps, an air arm of the British Army during the First World War, up to the time of the Kargil war. The indoor gallery features models of all aircraft, photographs of all the leaders of Air Staff, all IAF personnel killed in battle or in military operations, and uniforms. The open-air galleries display heavy weapons, military vehicles, and, of course, aircraft. All equipment used by the IAF has also been showcased, such as real war prizes, radio detection, and ranging equipment, and captured military vehicles. If you happen to get the chance to visit the museum on the Annual Air Force Day, you will be treated to views of vintage aircraft, which are usually off-limits to civilians."]
    
    //Mark : archaeological Array
    var ArrarchaeologicalName : [String] = ["Indian Museum in Kolkata","National Museum in New Delhi","Salar Jung Museum in Hyderabad","Chhatrapati Shivaji Maharaj in Mumbai","Government Museum in Chandigarh"]
    var ArrarchaeologicalImg : [String] = ["ic_kolkata","ic_national_Delhi","ic_salar-hyderbad","ic_Shivaji","ic_Art"]
    var ArrarchaelogicalDetail : [String] = ["Founded in 1814, the Indian Museum is not only India's oldest museum but also one of the largest in the country. It boasts an extensive and diverse collection of artifacts that span over 5,000 years of history. This collection includes items from various ancient civilizations, such as the Indus Valley Civilization, as well as sculptures, pottery, coins, and relics from the Mauryan and Gupta periods. The museum is a vital institution for archaeology, anthropology, and art enthusiasts, and it serves as a significant cultural and educational center.","The National Museum in New Delhi is a prestigious institution known for its comprehensive collection of art, archaeology, and cultural artifacts. It houses an impressive array of exhibits from different regions and time periods in India. The museum's diverse holdings encompass sculptures, paintings, manuscripts, jewelry, and historical artifacts, providing a comprehensive overview of India's rich cultural heritage.","The Salar Jung Museum is celebrated for its eclectic collection of art and antiques. It features a wide range of artifacts from across the world, including India, China, Europe, and the Middle East. The collection includes rare manuscripts, sculptures, textiles, furniture, and much more. It's a testament to the passion and discerning taste of Salar Jung III, whose personal collection forms the foundation of this museum.","This museum is renowned for its extensive collection of ancient Indian art, sculptures, decorative arts, and artifacts. The exhibits provide insights into the cultural history of India and beyond. It features an impressive collection of sculptures from different periods, including the Gupta and Chalukya dynasties, along with exquisite examples of decorative arts.","Situated in Chandigarh, this museum and art gallery focuses on the history and heritage of the region. It houses a significant collection of archaeological and art objects, including items related to the Indus Valley Civilization and artifacts from the Punjab region. The museum also hosts temporary exhibitions and cultural events."]
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "CellT_MusemDetail", bundle: nil), forCellReuseIdentifier: "CellT_MusemDetail")
        tableView.register(UINib(nibName: "Header", bundle: nil), forHeaderFooterViewReuseIdentifier: "Header")
    }
}
extension ViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let selectedIndex = selectedIndex{
            switch selectedIndex {
            case 0 :
                return ArrFineArt.count
            case 1 :
                return ArrHistoricalname.count
            case 2 :
                return ArrScienceName.count
            case 3 :
                return ArrmilitaryName.count
            case 4 :
                return ArrarchaeologicalName.count
            default :
                return 0
            }
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let selectedIndex = selectedIndex{
            switch selectedIndex{
            case 0 :
                let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_MusemDetail") as! CellT_MusemDetail
                cell.lbl_nameMuseum.text = ArrFineArt[indexPath.row]
                cell.img_museum.image = UIImage(named: ArrFineImg[indexPath.row])
                cell.img_museum.layer.cornerRadius = 5
                cell.selectedBackgroundView?.isHidden = true
                return cell
            case 1:
                let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_MusemDetail") as! CellT_MusemDetail
                cell.lbl_nameMuseum.text = ArrHistoricalname[indexPath.row]
                cell.img_museum.image = UIImage(named: ArrHistoricalimg[indexPath.row])
                cell.img_museum.layer.cornerRadius = 5
                cell.selectedBackgroundView?.isHidden = true
                return cell
            case 2:
                let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_MusemDetail") as! CellT_MusemDetail
                cell.lbl_nameMuseum.text = ArrScienceName[indexPath.row]
                cell.img_museum.image = UIImage(named: ArrScineceImg[indexPath.row])
                cell.img_museum.layer.cornerRadius = 5
                cell.selectedBackgroundView?.isHidden = true
                return cell
            case 3 :
                let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_MusemDetail") as! CellT_MusemDetail
                cell.lbl_nameMuseum.text = ArrmilitaryName[indexPath.row]
                cell.img_museum.image = UIImage(named: ArrmilitaryImg[indexPath.row])
                cell.img_museum.layer.cornerRadius = 5
                cell.selectedBackgroundView?.isHidden = true
                return cell
            case 4:
                let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_MusemDetail") as! CellT_MusemDetail
                cell.lbl_nameMuseum.text = ArrarchaeologicalName[indexPath.row]
                cell.img_museum.image = UIImage(named: ArrarchaeologicalImg[indexPath.row])
                cell.img_museum.layer.cornerRadius = 5
                cell.selectedBackgroundView?.isHidden = true
                return cell
            default :
                return UITableViewCell()
            }
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if let selectedIndex = selectedIndex{
            switch selectedIndex{
            case 0:
                return "Fine Arts"
            case 1:
                return "Historical"
            case 2 :
                return "Science & Technology"
            case 3 :
                return " Militiory"
            case 4 :
                return "Archaeological"
            default :
                return ""
            }
        }
        return ""
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if let selectedIndex = selectedIndex{
            switch selectedIndex{
            case 0:
                let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "Header") as! Header
                headerView.mylbl.text = "Fine Arts"
                headerView.myView.layer.cornerRadius = 5
                return headerView
            case 1:
                let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "Header") as! Header
                headerView.mylbl.text = "Historical"
                headerView.myView.layer.cornerRadius = 5
                return headerView
            case 2 :
                let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "Header") as! Header
                headerView.mylbl.text = "Science & Technology"
                headerView.myView.layer.cornerRadius = 5
                return headerView
            case 3 :
                let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "Header") as! Header
                headerView.mylbl.text = "Militiory"
                headerView.myView.layer.cornerRadius = 5
                return headerView
            case 4 :
                let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "Header") as! Header
                headerView.mylbl.text = "Archaeological"
                headerView.myView.layer.cornerRadius = 5
                return headerView
            default :
                return UITableViewCell()
            }
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 270
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MusemDetailVC") as? MusemDetailVC
        if let selectedIndex = selectedIndex{
            switch selectedIndex{
            case 0:
                vc?.artScience = ArrFineDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 1 :
                vc?.historical = ArrHistoryDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 2 :
                vc?.science = ArrScienceDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 3 :
                vc?.military = ArrmilitaryDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 4 :
                vc?.archaeological = ArrarchaelogicalDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            default : break
            }
        }
    }
}
