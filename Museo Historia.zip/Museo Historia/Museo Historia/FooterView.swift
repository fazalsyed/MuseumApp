//
//  FooterView.swift
//  TableView Testing
//
//  Created by syed fazal abbas on 08/04/23.
//

import UIKit

class FooterView: UITableViewHeaderFooterView {

    @IBOutlet var mylbl: UILabel!
}
